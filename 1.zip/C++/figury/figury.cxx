/*
 * figury.cxx
 */


#include <iostream>

using namespace std;

int prostokat1(){
    a = 10
    b = 10
        for(int i = 0; i <= a; i++){
            for(j = 0; j <= b; i++){
                cout << "#" << endl;
            }
        }
    }

int main(int argc, char **argv)
{
	int a, b;
    a = b = 0;
    prost1 = prostokat1();
    cout << prost1;
	return 0;
}

