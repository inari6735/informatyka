/*
 * anagramy.cpp
 */


#include <iostream>

using namespace std;

int main(int argc, char **argv)
{
	char wyraz[] = "ryba";
    int i1, i2, i3, i4;
    int r = 4;
    i1 = i2 = i3 = i4 = 0;
    for(i1 = 0; i1 < r; i1++){
        for(i2 = 0; i2 < r; i2++){
            if(i1 == i2) continue;
            //cout << i1 << i2 << endl;
            for(i3 = 0; )
        }
    }
	return 0;
}

